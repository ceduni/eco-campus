# Conception

## Architecture

- Décrire l'architecture du système proposé.

## Choix technologiques

- Justifier les technologies et outils choisis.

## Modèles et diagrammes

- Inclure des diagrammes UML, maquettes, etc.

## Prototype

- Inclure des diagrammes UML, maquettes, etc.
