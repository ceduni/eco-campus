# Évaluation

## Plan de test

- Décrire la stratégie de test.

## Critères d'évaluation

- Présenter les critères utilisés pour évaluer le système.

## Analyse des résultats

- Discuter des résultats obtenus lors des tests.
