# Études préliminaires

## Analyse du problème

- Décrire le problème à résoudre.

## Exigences

- Lister les exigences fonctionnelles et non fonctionnelles.

## Recherche de solutions

- Présenter les solutions existantes et justifier le choix retenu.

## Méthodologie

