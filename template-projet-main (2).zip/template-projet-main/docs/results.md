# Résultats

## Fonctionnalités

- Décrire les fonctionnalités implémentées.

## Démonstration

- Inclure des captures d'écran ou des démonstrations du système.

## Bilan

- Évaluer la réalisation des objectifs initiaux.
